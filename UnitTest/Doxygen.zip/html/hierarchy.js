var hierarchy =
[
    [ "unittest.TestCase", null, [
      [ "unitTest.TestRobotSystemCSV", "classunit_test_1_1_test_robot_system_c_s_v.html", null ],
      [ "unitTest.TestRobotSystemTCP", "classunit_test_1_1_test_robot_system_t_c_p.html", null ]
    ] ]
];